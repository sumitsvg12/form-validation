import React from 'react'
import { useState } from 'react'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


export default function Form(){
    
    const [email, setEmail] =useState("");
    const [password, setPassword] =useState("");

    const [error, setError] =useState({})
    


    const handleSubmit = (e) => {
        e.preventDefault();




        let errorObj = {};

        if (!email) {
            errorObj.email = "Email is required"
        }

        if (!password) {
            errorObj.password = "Password is required"
        } else if (password.length < 6) {
            errorObj.password = "Password should be at least 6 characters"
        }

        if (Object.keys(errorObj).length > 0) {
            setError(errorObj)
        } else {
            console.log(email, password)
            setEmail("")
            setPassword("")
            
            toast.success("Success Notification !", {
                position: "top-center",
            });


            setError({})
        }


    }


    return (
        <div>


            <div className="container">
                <form className='form-box' onSubmit={handleSubmit} >


                <h2>Login</h2>
            <div className="input-box">
                <input type="email"  placeholder="Enter your email" value={email} onChange={(e) => setEmail(e.target.value)}/>
                {error.email && < p > {error.email}</p>}
            </div>
            <div className="input-box">
                <input type="Password"  placeholder="Enter your Password" value={password} onChange={(e) => setPassword(e.target.value)}/>
                {error.password && <p >{error.password}</p>}
            </div>    
            <button className='btn' >Login</button>
            <br /> <br />

                {/* <label >


                    <input className='form-input' type="email" placeholder='Enter your email' value={email} onChange={(e) => setEmail(e.target.value)} />
                    {error.email && < p style={{ color: "red" }} > {error.email}</p>}


                </label>   <br /> <br />


                <label >
                    <input className='form-input' type="password" placeholder='Enter your password ' value={password} onChange={(e) => setPassword(e.target.value)} />
                    {error.password && <p style={{ color: "red" }} >{error.password}</p>}
                </label>
                <br /> <br />


                <button className='form-button' >Submit</button> */}


            </form>
            </div>



            <ToastContainer />
        </div >
    )
}


